// Minimal LLM proxy: keeps the vendor API key OFF the phone.
//   POST /v1/chat  {conversation_id, system, messages[], tools[]}
//   ->             {text?, tool_calls?: [{id, name, arguments}]}
// The wire format is provider-neutral; only this file knows about Anthropic.
// To switch vendor, rewrite `callLlm()` and keep the same request/response shape.
import express from 'express';

const PORT = process.env.PORT || 8080;
const MODEL = process.env.LLM_MODEL || 'claude-sonnet-5-5';
const API_KEY = process.env.ANTHROPIC_API_KEY;
if (!API_KEY) {
  console.error('Missing ANTHROPIC_API_KEY (set it in the server environment).');
  process.exit(1);
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));

const httpError = (status, message) => Object.assign(new Error(message), { status });

// ---- 1. Authentication -------------------------------------------------------
// Replace with real verification, e.g. Firebase Admin:
//   const decoded = await admin.auth().verifyIdToken(token); return { uid: decoded.uid };
async function authenticate(req) {
  if (process.env.DEV_ALLOW_ANON === 'true') return { uid: 'dev' };
  const h = req.get('authorization') || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) throw httpError(401, 'Missing bearer token');
  throw httpError(501, 'Token verification not configured: implement authenticate()');
}

// ---- 2. Naive per-user rate limit (use Redis / API gateway in production) ------
const hits = new Map();
function rateLimit(uid, max = 30, windowMs = 60_000) {
  const now = Date.now();
  const arr = (hits.get(uid) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) throw httpError(429, 'Too many requests');
  arr.push(now);
  hits.set(uid, arr);
}

// ---- 3. Format conversion: neutral -> Anthropic Messages ------------------------
function toAnthropicMessages(messages) {
  const out = [];
  const push = (role, blocks) => {
    const last = out[out.length - 1];
    if (last && last.role === role) last.content.push(...blocks); // merge same-role
    else out.push({ role, content: blocks });
  };
  for (const m of messages) {
    if (m.role === 'user') {
      push('user', [{ type: 'text', text: String(m.content ?? '') }]);
    } else if (m.role === 'assistant') {
      const blocks = [];
      if (m.content && String(m.content).trim()) blocks.push({ type: 'text', text: String(m.content) });
      for (const c of m.tool_calls || []) {
        blocks.push({ type: 'tool_use', id: c.id, name: c.name, input: c.arguments || {} });
      }
      if (blocks.length) push('assistant', blocks);
    } else if (m.role === 'tool') {
      // consecutive tool results are merged into ONE user message (API requirement)
      push('user', [{ type: 'tool_result', tool_use_id: m.tool_call_id, content: String(m.content ?? '') }]);
    }
  }
  return out;
}

async function callLlm({ system, messages, tools }) {
  const body = {
    model: MODEL,
    max_tokens: 1024,
    temperature: 0.2,
    system,
    messages: toAnthropicMessages(messages),
    tools: tools.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters })),
  };
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(25_000),
  });
  if (!resp.ok) {
    console.error('LLM upstream error', resp.status, (await resp.text()).slice(0, 500));
    throw httpError(resp.status === 429 ? 429 : 502, 'Upstream LLM error');
  }
  const data = await resp.json();
  const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
  const tool_calls = (data.content || [])
    .filter((b) => b.type === 'tool_use')
    .map((b) => ({ id: b.id, name: b.name, arguments: b.input || {} }));
  return { text: text || undefined, tool_calls };
}

// ---- 4. Route ------------------------------------------------------------------
app.post('/v1/chat', async (req, res) => {
  try {
    const { uid } = await authenticate(req);
    rateLimit(uid);
    const { system, messages, tools } = req.body || {};
    if (typeof system !== 'string' || system.length > 30_000) throw httpError(400, 'bad system');
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 80) throw httpError(400, 'bad messages');
    if (!Array.isArray(tools) || tools.length > 20) throw httpError(400, 'bad tools');
    res.json(await callLlm({ system, messages, tools }));
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error(e);
    res.status(status).json({ error: status >= 500 ? 'server_error' : e.message });
  }
});

app.get('/healthz', (_req, res) => res.json({ ok: true }));

export { toAnthropicMessages };
if (process.argv[1] && import.meta.url === new URL(`file://${process.argv[1]}`).href) {
  app.listen(PORT, () => console.log(`AI proxy listening on :${PORT}`));
}
